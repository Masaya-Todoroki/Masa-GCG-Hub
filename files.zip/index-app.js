        // Tab switching. To add a tab: add a button with data-tab="your-id"
        // and a matching <div id="your-id" class="tab-content">...</div>.
        const tabButtons = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));

                button.classList.add('active');
                document.getElementById(button.dataset.tab).classList.add('active');
            });
        });
    

// News: loaded from the Cloudflare Worker (worker/news-worker.js).
// After deploying the Worker, paste its URL here:
const NEWS_API_URL = 'https://YOUR-WORKER.workers.dev/';

const newsAccounts = { ENG: 'English', JP: 'Japanese' };
let activeNewsAccount = 'ENG';
let newsAttempted = false;
let newsRenderToken = 0;
const newsCache = {};

function formatNewsDate(iso) {
    const d = new Date(iso + 'T00:00:00');
    return isNaN(d) ? iso : d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function renderNewsItems(items) {
    const holder = document.getElementById('news-timeline');
    holder.replaceChildren();
    const list = document.createElement('ul');
    list.className = 'news-list';
    items.forEach(item => {
        const li = document.createElement('li');
        const a = document.createElement('a');
        a.className = 'news-item';
        a.href = item.url;
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        const meta = document.createElement('span');
        meta.className = 'news-meta';
        meta.textContent = `${formatNewsDate(item.date)} · ${item.category}`;
        const title = document.createElement('span');
        title.className = 'news-title';
        title.textContent = item.title;
        a.append(meta, title);
        li.appendChild(a);
        list.appendChild(li);
    });
    holder.appendChild(list);
}

async function loadNews() {
    newsAttempted = true;
    const token = ++newsRenderToken;
    const account = activeNewsAccount;
    const status = document.getElementById('news-loading');
    document.getElementById('news-timeline').replaceChildren();
    status.hidden = false;
    status.textContent = `Loading ${newsAccounts[account]} news…`;
    try {
        if (!newsCache[account]) {
            const res = await fetch(`${NEWS_API_URL}?lang=${account}`);
            if (!res.ok) throw new Error(`News API returned ${res.status}`);
            newsCache[account] = (await res.json()).items;
        }
        if (token !== newsRenderToken) return;
        renderNewsItems(newsCache[account]);
        status.hidden = true;
    } catch (error) {
        if (token !== newsRenderToken) return;
        status.textContent = 'News could not be loaded right now. Use the link above to open the official account.';
        console.warn('News unavailable:', error);
    }
}

document.querySelectorAll('.news-lang-btn').forEach(button => {
    button.addEventListener('click', () => {
        if (button.dataset.account === activeNewsAccount) return;
        activeNewsAccount = button.dataset.account;
        document.querySelectorAll('.news-lang-btn').forEach(btn => {
            const selected = btn === button;
            btn.classList.toggle('active', selected);
            btn.setAttribute('aria-pressed', String(selected));
        });
        const link = document.getElementById('news-account-link');
        link.href = `https://x.com/GUNDAM_GCG_${activeNewsAccount}`;
        link.textContent = `Open ${newsAccounts[activeNewsAccount]} X account`;
        if (document.getElementById('news').classList.contains('active')) loadNews();
    });
});
document.querySelector('[data-tab="news"]')?.addEventListener('click', () => {
    if (!newsAttempted) loadNews();
});
