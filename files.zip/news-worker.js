// Cloudflare Worker: reads the official Gundam Card Game news lists and returns JSON.
// Usage: https://YOUR-WORKER.workers.dev/?lang=ENG   or   ?lang=JP
// Results are cached for 30 minutes, so the official site is hit rarely.

const SOURCES = {
  ENG: 'https://www.gundam-gcg.com/en/news/',
  JP:  'https://www.gundam-gcg.com/jp/news/',
};
const CACHE_SECONDS = 1800;
const MAX_ITEMS = 12;
const ALLOWED_ORIGIN = '*'; // change to 'https://your-site.com' once it works

const MONTHS = { jan:1, feb:2, mar:3, apr:4, may:5, jun:6, jul:7, aug:8, sep:9, oct:10, nov:11, dec:12 };

function parseDate(text) {
  let m = text.match(/([A-Z][a-z]{2})[a-z]*\.? (\d{1,2}), (\d{4})/);
  if (m && MONTHS[m[1].toLowerCase()]) return { iso: `${m[3]}-${String(MONTHS[m[1].toLowerCase()]).padStart(2,'0')}-${m[2].padStart(2,'0')}`, raw: m[0] };
  m = text.match(/(\d{4})[./年-](\d{1,2})[./月-](\d{1,2})/);
  if (m) return { iso: `${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`, raw: m[0] };
  return null;
}

function clean(html) {
  return html.replace(/<[^>]*>/g, ' ')
    .replace(/&amp;/g, '&').replace(/&#0?39;|&apos;/g, "'").replace(/&quot;/g, '"')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ').trim();
}

function parseNews(html, baseUrl) {
  const items = [];
  const seen = new Set();
  const re = /<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let match;
  while ((match = re.exec(html))) {
    const text = clean(match[2]);
    const date = parseDate(text);
    if (!date) continue; // only list entries have a date inside the link
    const url = new URL(match[1], baseUrl).href;
    if (seen.has(url)) continue;
    const title = text
      .replace(date.raw, '')
      .replace(/LEARN MORE|詳しく見る|詳細はこちら|もっと見る/gi, '')
      .replace(/\s+/g, ' ').trim();
    // The title is often repeated (once as image alt, once as text): collapse it.
    const half = title.length / 2;
    const deduped = title.length % 2 === 1 && title.slice(0, half) === title.slice(half + 1) ? title.slice(0, half) : title;
    const path = url.toLowerCase();
    const category = path.includes('/products/') ? 'Products' : path.includes('/events/') ? 'Events' : 'News';
    if (!deduped) continue;
    seen.add(url);
    items.push({ title: deduped, url, date: date.iso, category });
    if (items.length >= MAX_ITEMS) break;
  }
  return items;
}

export default {
  async fetch(request, env, ctx) {
    const cors = { 'Access-Control-Allow-Origin': ALLOWED_ORIGIN };
    if (request.method === 'OPTIONS') return new Response(null, { headers: { ...cors, 'Access-Control-Allow-Methods': 'GET' } });

    const lang = (new URL(request.url).searchParams.get('lang') || 'ENG').toUpperCase();
    const source = SOURCES[lang];
    if (!source) return new Response(JSON.stringify({ error: 'lang must be ENG or JP' }), { status: 400, headers: { ...cors, 'Content-Type': 'application/json' } });

    const cache = caches.default;
    const cacheKey = new Request(`https://news-cache.local/${lang}`);
    const cached = await cache.match(cacheKey);
    if (cached) return new Response(cached.body, { headers: { ...cors, 'Content-Type': 'application/json', 'X-Cache': 'HIT' } });

    const upstream = await fetch(source, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; GCGHubNews/1.0)' } });
    if (!upstream.ok) return new Response(JSON.stringify({ error: `Upstream ${upstream.status}` }), { status: 502, headers: { ...cors, 'Content-Type': 'application/json' } });

    const items = parseNews(await upstream.text(), source);
    if (!items.length) return new Response(JSON.stringify({ error: 'No news items found (page layout may have changed)' }), { status: 502, headers: { ...cors, 'Content-Type': 'application/json' } });

    const body = JSON.stringify({ lang, source, updated: new Date().toISOString(), items });
    ctx.waitUntil(cache.put(cacheKey, new Response(body, { headers: { 'Content-Type': 'application/json', 'Cache-Control': `max-age=${CACHE_SECONDS}` } })));
    return new Response(body, { headers: { ...cors, 'Content-Type': 'application/json', 'X-Cache': 'MISS' } });
  },
};
